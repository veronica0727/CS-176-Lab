package edu.monmouth.cs176.s1125739.midterm;
import java.util.*;

public class Artist 
{
	private String firstName;
	private String lastName;
	public ArrayList<Record> records;
	
	Artist (String fName, String lName)
	{
		this.firstName = fName;
		this.lastName = lName;
		this.records = new ArrayList<Record>();
		
	}
	public String toString()
	{
		return 
				"Name: " + this.firstName + " " +
				this.lastName + "\n";
	}
	
	public void addRecord (Record r)
	{ 
		 this.records.add(r); 
	
	}
}
