package edu.monmouth.cs176.s1125739.midterm;
import java.util.*;
public class MidtermTest 
{
	public static void main(String [] args)
	{
		ArtistList artist = new ArtistList();
		
		Artist a1 = new Artist (" Jessie ", "Reyez");
		Artist a2 = new Artist ("Lana", "Del Rey");
		Artist a3 = new Artist ("J", "Cole");
		
		artist.addArtist(a1);
		artist.addArtist(a2);
		artist.addArtist(a3);
		
		Albums ab1 = new Albums ("2007", "R&B/Soul", "Kiddo");
		Albums ab2 = new Albums ("2012", "Rock", "Born to Die");
		Albums ab3 = new Albums ("2017", " Dream Pop", " Lust for Life");
		Albums ab4 = new Albums ("2015", "Jazz", "Honeymoon");
		Albums ab5 = new Albums ("2018", " R&B/Soul", "Being Human in Public");
		Albums ab6 = new Albums ("2005", "Country", "MidSummer");
		Albums ab7 = new Albums ("2010", "Rap", "Diamond");
		Albums ab8 = new Albums ("2002", "Punk Rock", "Endless Dreams");
		
		
		Record r1 = new Record (ab1);
		Record r2 = new Record (ab2);
		Record r3 = new Record (ab3);
		Record r4 = new Record (ab4);
		Record r5 = new Record (ab5);
		Record r6 = new Record (ab6);
		Record r7 = new Record (ab7);
		Record r8 = new Record (ab8);
		
		a1.addRecord(r1);
		a1.addRecord(r5);
		a1.addRecord(r4);
		a1.addRecord(r8);
		
		a2.addRecord(r2);
		a2.addRecord(r3);
		a2.addRecord(r4);
		a2.addRecord(r8);
		
		a3.addRecord(r6);
		a3.addRecord(r7);
		a3.addRecord(r8);
		
		
		artist.listArtists();
	
	}
	
	
}
