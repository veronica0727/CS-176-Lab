package edu.monmouth.cs176.s1125739.midterm;
import java.util.*;


public class ArtistList 
{
	ArrayList<Artist> artist;
	private int count = 0;
	
	ArtistList ()
	{
		artist = new ArrayList<Artist>();
	}
	
	public void addArtist(Artist a)
	{
		artist.add(a);
	}
	public void listArtists()
	{
		for (Artist a : artist)
		{
			System.out.println("=========Artist=============\n");
			System.out.println(a.toString());
			System.out.println("==========Album(s)=============\n");
			for(Record r : a.records)
			{
				System.out.println(r.toString() + "\n");
			}
		} System.out.println("\n");
			
			
		}
	}

