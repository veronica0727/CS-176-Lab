package edu.monmouth.cs176.s1125739.midterm;
import java.util.*;
public class Albums 
{
	private String albumDate;
	private String albumGenre;
	private String albumName;
	
	Albums (String date, String genre, String name)
	{
		this.albumDate = date;
		this.albumGenre = genre;
		this.albumName = name;
		
	}
	
	public String toString()
	{
		return 
				"Album Relase Date: " + this.albumDate + "\n" +
				"Album Genre: " + this.albumGenre + "\n" +
				"Album Name: " + this.albumName;
	}
	
	public void setName(String name)
	{
		this.albumName = name;
	}
}
