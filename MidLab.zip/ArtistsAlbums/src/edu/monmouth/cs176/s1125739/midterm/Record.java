package edu.monmouth.cs176.s1125739.midterm;

public class Record 
{
	public Albums Albums;
	
	Record(Albums ab)
	{
		this.Albums = ab;
	
	}
	
	public String toString()
	{
		return 
				this.Albums.toString();
	}
}
