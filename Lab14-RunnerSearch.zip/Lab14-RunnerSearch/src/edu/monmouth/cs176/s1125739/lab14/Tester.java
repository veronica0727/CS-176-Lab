package edu.monmouth.cs176.s1125739.lab14;

import java.util.Scanner;

public class Tester 
{
	private static RunnerList runners = new RunnerList();
		Scanner userInput = new Scanner (System.in);
	   
		//prompt for Runner, call FindRunner 
		//if found display info
		//if not display message
		public static void find(Scanner userInput) 
		{
			System.out.println ("Enter Runner's Last Name:");
			String RunnerInfo = userInput.nextLine();
			Runner r = runners.findRunnerByLastName(RunnerInfo);
			if(r != null)
			{
				System.out.println(r.toString());
			}
			else
			{
				System.out.println("Runner Not Found!");
			}
			
			
		}
		// prompt for t-shirt size. Validate to known sizes
		// get count for entered size. If not valid size, display message
		public static void tShirtCount(Scanner userInput) 
		{
			System.out.println ("Enter Shirt Size:");
			String ShirtInfo = userInput.nextLine();
			Integer run = runners.getTshirtCount(ShirtInfo);
			if(run != null)
			{
				System.out.println(run.intValue());
			}
			else
			{
				System.out.println("No Size Found!");
			}
			
		}
		// console prompt to (F)ind, (T)shirt count or (Q)uit
		// If F, invoke findRunner. If T, invoke tShirtCount.
		//  Q exists do while loop
		public static void main(String[] args) 
		{
			Scanner userInput = new Scanner (System.in);
		    String action = "";
			boolean quit = false;
			do {
				System.out.print ("Enter (F)ind Runner, (T)Shirt Size, (Q)uit: ");
				action = userInput.nextLine();
				action = action.toLowerCase();
				switch (action) {
				case "q":
					quit = true;
					break;
				case "f":
					System.out.println("Find Runner");
					find(userInput);
					break;
				case "t":
					System.out.println("T-Shirt Size");
					tShirtCount(userInput);
					break;
				default:
					System.out.println ("Invalid Action - Try again");
					break;
				}
			} while (!quit);
			System.out.println ("Good Bye");
			userInput.close();
			
	}
	
}
