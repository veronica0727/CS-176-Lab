package edu.monmouth.cs176.s1125739.lab14;

import java.util.ArrayList;
import java.util.Arrays;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class RunnerList {

	ArrayList<Runner> runnersList = new ArrayList<Runner> ();
	
	RunnerList() {
		readCSVData();
	}
	
	private void readCSVData() {
		String csvFile = "/Users/veronicamarquez/eclipse-workspace/Lab14-RunnerSearch/runners.csv";
        String line = "";
        String cvsSplitBy = ",";
        int lineCount = 0;
        try (BufferedReader br = new BufferedReader(new FileReader(csvFile))) {

            while ((line = br.readLine()) != null) {

                // use comma as separator
                String[] lineElements = line.split(cvsSplitBy);

                
                if (lineCount > 0) {
                	Runner r = new Runner (lineElements[0],
                						   lineElements[1],
                						   lineElements[2],
                						   lineElements[3],
                						   lineElements[4],
                						   lineElements[5],
                						   lineElements[6],
                						   lineElements[7],
                						   lineElements[8],
                						   lineElements[9]
                						  );
                	runnersList.add(r);
                }
                lineCount++;

            }

        } catch (IOException e) {
            e.printStackTrace();
        }
	}
	
	public Integer totalRunners() {
		return runnersList.size();
	}
	
	
	public Runner findRunner (String ID) {
		Runner foundRunner = null;
		for (Runner r: runnersList) {
			if (r.getID().equals(ID)) {
				foundRunner = r;
				return foundRunner;
			}
		}
		
		return foundRunner;
	}
	
	public Runner findRunnerByLastName(String lName)
	{
		Runner foundRunnerLastName = null;
		for(Runner r: runnersList)
			{
				if(r.getLastName().equalsIgnoreCase(lName))
			{
					foundRunnerLastName = r;
					return foundRunnerLastName;
			}

			}
		return foundRunnerLastName;
	}
	public boolean deleteRunner (String ID) {
		boolean result = false;
		Runner runner = findRunner(ID);
		if (runner != null) {
					
			if (runnersList.remove(runner)) {
				System.out.println(runner.toString());
				return true;
			}
		}
		return result;
		
	}
	
	public Integer getTshirtCount (String size) {
		Integer count = 0;
		for (Runner r: runnersList) {			
			if (r.getTshirtSize().equals(size)) {
				count++;				
			}
		}	
		return count;
	}
	
	public Integer [] getTshirtCountForSizes (String[] sizes) {
		Integer [] counts;
	
		counts = new Integer[sizes.length];
		Arrays.fill(counts, 0);		
		
		for (Runner r: runnersList) {	
			
			int index = 0;
			while (index < sizes.length) {
				if (sizes[index].equals(r.getTshirtSize())) {
					counts[index]++;
					break;
				} else {
					index++;
				}
			}
		}
		
		return counts;
	}
	
}

