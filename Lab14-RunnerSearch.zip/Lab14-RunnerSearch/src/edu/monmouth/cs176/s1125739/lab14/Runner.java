package edu.monmouth.cs176.s1125739.lab14;

public class Runner 
{
	private String ID;
	private String firstName;
	private String lastName;
	private String gender;
	private String age;
	private String email;
	private String tShirtSize;
	private String state;
	private String zipCode;
	private String uuid;
	
	Runner (String ID,
	        String firstName,
			String lastName,
			String gender,
			String age,
			String email,
			String tShirtSize,
			String state,
			String zipCode,
			String uuid) {
		
		this.ID = ID;
		this.firstName = firstName;
		this.lastName = lastName;
		this.gender = gender;
		this.age = age;
		this.email = email;
		this.tShirtSize = tShirtSize;
		this.state = state;
		this.zipCode = zipCode;
		this.uuid = uuid;
		
	}
	
	public String getID () {
		return this.ID;
	}
	
	public String getLastName() {
		return this.lastName;
	}
	
	public String getTshirtSize () {
		return this.tShirtSize;
	}
	
	
	public String toString () {
		return "ID: " + this.ID + "\n" +
		"First Name: " + this.firstName + "\n" +
		"Last Name: " +this.lastName + "\n" +
		"Gender: " +this.gender + "\n" +
		"Age: " +this.age + "\n" +
		"Email: " +this.email + "\n" +
		"T-Shirt Size: " +this.tShirtSize + "\n" +
		"State: " +this.state + "\n" +
		"Zipcode: " +this.zipCode  + "\n" +
		"UUID: " + this.uuid;
	}
}
