package edu.monmouth.cs176.s1125739.lab11;

public interface StudentList 
{
	void addStudent(String id, String fName, String lName, int level, double gpa);
	Student topStudentInClass(int classLevel);
	double averageClassLevelGPA(int classLevel);
	int totalStudents(); //*** add this method declaration
}
