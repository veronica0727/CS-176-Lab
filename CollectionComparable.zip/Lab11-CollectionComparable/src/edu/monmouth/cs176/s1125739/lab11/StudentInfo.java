package edu.monmouth.cs176.s1125739.lab11;

public interface StudentInfo 
{
	String getStudentInfo(Student s);
}
