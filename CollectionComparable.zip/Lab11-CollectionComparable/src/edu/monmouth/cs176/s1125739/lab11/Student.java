package edu.monmouth.cs176.s1125739.lab11;

public class Student implements Comparable <Student>
{
	public String id;
	public String firstName;
	public String lastName;
	public int classLevel; //1-Freshmen, 2-Sophomore, 3-Juniors, 4-Seniors
	public double gpa;
	
	Student (String id, String fName, String lName, int level, double gpa)
	{
		this.id = id;
		this.firstName = fName;
		this.lastName = lName;
		this.classLevel = level;
		this.gpa = gpa;
	}
	
	public String getID()
	{
		return id;
	}
	
	
	public String getFirstName()
	{
		return firstName;
	}
	
	public String getLastName()
	{
		return lastName;
	}
	
	public int getClassLevel()
	{
		return classLevel;
	}
	public void setClassLevel(int level)
	{
		classLevel = level;
	}
	
	public double getGPA()
	{
		return gpa;
	}

	@Override
	//Comparing every students gpa 
	public int compareTo(Student s) 
	{
		Student otherStudent = (Student) s;
		if(getGPA() > otherStudent.getGPA())
			return 1;
		else if(getGPA() == otherStudent.getGPA())
			return 0;
		else return -1;
	}

	
	
	
}
