package edu.monmouth.cs176.s1125739.lab11;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
public class Tester 
{

	static StudentInfoAndList csseStudents = new StudentInfoAndList();
	static String classLevels [] = new String [] {"Freshmen: ", "Sophomore: ", "Junior: ", "Senior: "};

	public static void main(String[] args) {
		
		readCSV();		// get students from CSV file
		
		/*System.out.println ("----  Total Students -------");
		System.out.println (csseStudents.totalStudents());
		
		System.out.println ("----  AVERAGE GPAs -------");
		classAverage(1);
		classAverage(2);
		classAverage(3);
		classAverage(5);
		
		System.out.println ("----- Top Students -------");
		showTopStudent(1);
		showTopStudent(2);
		showTopStudent(3);
		showTopStudent(4);	*/
		
		System.out.println("--------Students Sorted by GPA-------");
		showStudents(1);
		showStudents(2);
		showStudents(3);
		showStudents(4);
	}
	
	public static void showStudents (int level) 
	{
		System.out.print ("---- " + classLevels[level-1] );
		csseStudents.listStudentsInClass(level);
	}
	
	public static void classAverage(int level) {
		if (level > 0 && level < 5) {
			double GPA = csseStudents.averageClassLevelGPA(level);
			System.out.println(classLevels[level-1] + String.format("%.2f",GPA));
		} else {
			System.out.println("invalid class level " + level);
		}
	}
	
	public static void showTopStudent (int level) {
		if (level > 0 && level < 5) {
		    Student topStudent = csseStudents.topStudentInClass(level);
			if (topStudent != null) {
				System.out.println (classLevels[level-1] + csseStudents.getStudentInfo(topStudent));
			} else {
				System.out.println (classLevels[level-1] + "No students");
			}
		} else {
			System.out.println("invalid class level " + level);
		}
	}
	
	public static void readCSV() {	
		// you need to replace that path name to your src folder path
		String csvFile = "/Users/veronicamarquez/eclipse-workspace/Lab 10a-MultipleInterfacesImplementation/students.csv";
        
		String line = "";
        String cvsSplitBy = ",";
        int lineCount = 0;
        try (BufferedReader br = new BufferedReader(new FileReader(csvFile))) {

            while ((line = br.readLine()) != null) {

                // use comma as separator
                String[] lineElements = line.split(cvsSplitBy);

                if (lineCount > 0) {
                	int level = Integer.parseInt (lineElements[3]);
                	double gpa = Double.parseDouble(lineElements[4]);
                	csseStudents.addStudent (lineElements[0],
				                             lineElements[1],
				                             lineElements[2],
				                             level,
				                             gpa);
                }
                lineCount++;
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
	}
}


