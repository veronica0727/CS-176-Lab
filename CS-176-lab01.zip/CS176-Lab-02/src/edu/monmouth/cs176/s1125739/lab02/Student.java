package edu.monmouth.cs176.s1125739.lab02;
import java.util.*;

public class Student {
	private String name;
	private String studentID;
	private String email;
	private String major;
	private Integer classLevel;
	private String advisor;
	private Double credits;
	private Integer graduationYear;
	
	
	Student (String name, String sID, String email, String major, 
			Integer classLevel,String advisor, Double credits, Integer year)
	{
		this.name = name;
		this.studentID = sID;
		this.email = email;
		this.major = major;
		this.classLevel = classLevel;
		this.advisor = advisor;
		this.credits = credits;
		this.graduationYear = year;
		
	}

	
	public void setMajor (String major) 
	{
		this.major = major;
	}
	public String getMajor ()
	{
		return this.major;
	}
	public String toString()
	{
		return
				"Name: " + this.name + "\n" +
				"Student ID: " + this.studentID + "\n" +
				"Email: " + this.email + "\n" +
				"Major:" + this.major + "\n" +
				"Class: " + this.classLevel + "\n" +
				"Advisor: " + this.advisor +"\n" +
				"Credits:" + this.credits + "\n"+
				"graduaton Year: " + this.graduationYear + "\n";
	}
	
	public Integer getYear ()
	{
		return this.graduationYear;
	}
	
	

	public String getStudentID() {
		// TODO Auto-generated method stub
		return null;
	}


	public void setGraduationYear(Integer year) {
		// TODO Auto-generated method stub
		
	}


	
	public String getEmail() {
		return this.email;
	}
	
		
	
	
}