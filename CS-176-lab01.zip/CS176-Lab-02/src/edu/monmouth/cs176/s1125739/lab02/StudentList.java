package edu.monmouth.cs176.s1125739.lab02;
import java.util.*;

public class StudentList
{
	Student[] cs176Students;
	
	private int count = 0;
	
	StudentList (int totalStudents) 
	{
		cs176Students = new Student[totalStudents];
	}
	
	public void addStudent (Student s)
	{
		cs176Students[count]= s;
		count++;
	}
	
	
	public Student Find(String id)
	{
		Student foundStudent = null;
		for (Student s: cs176Students)
		{
			if (s.getStudentID()== id)
			{
				return s;
			}
		}
		return foundStudent;
		
	}
	public boolean updateGraduationYear (String id, Integer year)
	{
		boolean result = false;
		Student student = Find(id);
		if (student != null)
		{
			student.setGraduationYear(year);
			return true;
		}
		
		return result;
		
	}
	public void listStudents()
	{
		for (Student s: cs176Students)
		{
			System.out.println(s.toString());
		}
	}
	public int StudentCount(String major)
	{	int count = 0;
		for(Student s: cs176Students)
			if(s.getMajor()== major)
				count++;
	return count;
	}
	 public Student getStudentInfo(String email)
	{	
		 Student getStudent = null;
		for (Student s: cs176Students)
		{
			if (s.getEmail()== email)
			{
				return s;
			}
			
		}
		return getStudent;
		
	
	}
	 
}
