package edu.monmouth.cs176.s1125739.lab03;
import java.util.*;

public class StudentList
{
	ArrayList<Student> cs176Students;

	private int count = 0;

	StudentList () 
	{
		cs176Students = new ArrayList<Student>(); 
	}

	public void addStudent (Student s)
	{
		cs176Students.add(s);
	}


	public Student Find(String id)
	{
		Student foundStudent = null;
		for (Student s: cs176Students)
		{
			if (s.getStudentID()== id)
			{
				return s;
			}
		}
		return foundStudent;

	}
	public boolean updateGraduationYear (String id, Integer year)
	{
		boolean result = false;
		Student student = Find(id);
		if (student != null)
		{
			student.setGraduationYear(year);
			return true;
		}

		return result;

	}
	public void listStudents()
	{
		for (Student s: cs176Students)
		{
			System.out.println(s.toString());
		}
	}
	public int StudentCount(String major)
	{	int count = 0;
	for(Student s: cs176Students)
		if(s.getMajor()== major)
			count++;
	return count;
	}
	public Student getStudentInfo(String email)
	{	
		Student getStudent = null;
		for (Student s: cs176Students)
		{
			if (s.getEmail()== email)
			{
				return s;
			}

		}
		return getStudent;


	}
	public Student findStudentByKey(String key, String value)
	{
		Student foundStudent = null;
		String foundValue;
		for (Student s: cs176Students)
		{
			switch (key)
			{
			case "studentID":
				foundValue = s.getStudentID();
				break;
			case "email":
				foundValue =s.getEmail();
				break;
			default:
				foundValue = "";
			}


			if (foundValue == value)
			{
				return s;
			}

		}
		return foundStudent;
	

	
		
	}

}
