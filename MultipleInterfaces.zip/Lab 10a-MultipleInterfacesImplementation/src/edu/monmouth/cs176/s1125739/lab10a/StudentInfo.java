package edu.monmouth.cs176.s1125739.lab10a;

public interface StudentInfo 
{
	String getStudentInfo(Student s);
}
