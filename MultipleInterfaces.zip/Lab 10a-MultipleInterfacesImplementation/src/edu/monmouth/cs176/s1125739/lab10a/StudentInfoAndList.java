package edu.monmouth.cs176.s1125739.lab10a;
import java.util.*;


public class StudentInfoAndList implements StudentInfo, StudentList 
{
	ArrayList<Student> studentList = new ArrayList<Student>();
	
	
	@Override
	public void addStudent(String id, String fName, String lName, int level, double gpa) 
	{
		Student s = new Student (id, fName, lName, level, gpa);
		studentList.add(s);
		
	}

	@Override
	public Student topStudentInClass(int level) 
	{
		Student topStudent = null;
		for(Student s: studentList)
		{
			if (s.classLevel == level && topStudent != null)
			{
				if(s.gpa > topStudent.gpa)
				{
					topStudent = s;
				}
			} else if (s.classLevel == level)
			{
				topStudent = s;
			}
		}
		return topStudent;
	}

	@Override
	public double averageClassLevelGPA(int classLevel) 
	{
		double sum = 0;
		int count = 0;
		for (Student s: studentList)
		{	if(s.classLevel == classLevel)
			{
				sum = s.gpa + sum;
				count++;
		     
			}
		}

		double average = sum/count;
		return average;
		}
			
	

	@Override
	public int totalStudents() 
	{
		return studentList.size();
	}

	@Override
	public String getStudentInfo(Student s) 
	{
		return 
				s.getFirstName() + " " +  s.getLastName()  + " " + s.gpa;
		
		
	}

}
